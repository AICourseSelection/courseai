import json
import re
import requests
import time

from bleach import clean
from bs4 import BeautifulSoup


def get_degrees():
    with open("data/cecs-degree-codes.csv") as f:
        lines = f.readlines()
        lines = list(map(lambda s: s.replace(',', ''), lines))
        lines = list(map(lambda s: s.strip(), lines))
        lines = list(filter(lambda s: s != '', lines))
        return lines


# EXAMPLE URL = https://programsandcourses.anu.edu.au/2019/course/COMP1110#study
def get_raw_html(url):
    page = requests.get(url)
    # except (ConnectionError, ConnectionRefusedError, ConnectionAbortedError, ConnectionResetError):
    #     exit(0)  # change to a continue statement
    soup = BeautifulSoup(page.text, 'html.parser')
    return soup


def remove_tag(soup, tag_name):
    for tag in soup.findAll(tag_name):
        tag.replaceWithChildren()
    return soup


def list_to_string_helper(input_list):
    to_ret = ""

    for i in input_list:
        to_ret += (i + " ")

    return to_ret[:-1]


# returns the title, the relevant content
def get_intro(soup):
    title = soup.select('h1.intro__degree-title')[0].text.strip()

    intro = str(soup.find("div", {"id": "introduction"}).text)
    return title, intro


def get_h2s(soup):
    h2tags = soup.find_all('h2')
    pages = []

    for h2tag in h2tags:
        page = [str(h2tag)]
        elem = next_element(h2tag)
        while elem and elem.name != 'h2':
            page.append(str(elem))
            elem = next_element(elem)
        pages.append('\n'.join(page))

    return pages


def strip_html(src, allowed):
    return clean(src, tags=allowed, strip=True, strip_comments=True)


def next_element(elem):
    while elem is not None:
        # Find next element, skip NavigableString objects
        elem = elem.next_sibling
        if hasattr(elem, 'name'):
            return elem


def create_jsons():
    degrees = [1]  # get_degrees()
    years = [2013]  #  [2013, 2014, 2015, 2016, 2017, 2018, 2019, 2020]

    sections_that_do_not_matter = ['Indicative Assessment', 'Workload', 'Fees']
    sections_that_matter = ['Learning Outcomes', 'Requisite and Incompatibility', 'Prescribed Texts', 'Areas of Interest', 'Majors', 'Minors', 'Specialisations', 'Offerings and Dates']

    for year in years:
        for degree in degrees:

            time.sleep(0.005)

            url = "https://programsandcourses.anu.edu.au/2019/course/COMP1110#study"

            try:
                soup = get_raw_html(url)
                h2s = get_h2s(soup)
                # print(soup)
            except (ConnectionError, ConnectionRefusedError, ConnectionAbortedError, ConnectionResetError):
                continue

            # soup = remove_tag(soup, 'a')
            # soup = remove_tag(soup, 'p')
            # soup = remove_tag(soup, 'strong')

            scraped_content = get_intro(soup)

            if scraped_content is None:
                continue

            title, intro = scraped_content

            if intro is None:
                continue

            for section in h2s:
                section_header = re.search('<h2 id="[A-Za-z\s\-]{0,100}">[A-Za-z\s\-]{0,100}<\/h2>', section).group()
                section_header = BeautifulSoup(section_header, 'html.parser').text
                if section_header in sections_that_do_not_matter:
                    continue
                if section_header not in sections_that_matter:
                    print(degree, year, section_header)
                    continue
                print(section_header)
                header_end_position = section.index("</h2>")
                result_soup = BeautifulSoup(section[header_end_position + 5:], "html.parser")

                if section_header == "Offerings and Dates":
                    cleaned = str(result_soup)
                else:
                    cleaned = ' '.join(strip_html(str(result_soup), allowed=['li']).split())

                print(cleaned)


if __name__ == '__main__':
    create_jsons()
