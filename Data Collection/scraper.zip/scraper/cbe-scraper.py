import json
import re
import requests
import time
from bs4 import BeautifulSoup


def get_degrees():
    with open("data/cbe-degree-codes.csv") as f:
        lines = f.readlines()
        lines = list(map(lambda s: s.replace(',', ''), lines))
        lines = list(map(lambda s: s.strip(), lines))
        lines = list(filter(lambda s: s != '', lines))
        return lines


# Example URL = 'https://programsandcourses.anu.edu.au/2018/program/BACCT#study'
def get_raw_html(url):
    page = requests.get(url)
    # except (ConnectionError, ConnectionRefusedError, ConnectionAbortedError, ConnectionResetError):
    #     exit(0)  # change to a continue statement
    soup = BeautifulSoup(page.text, 'html.parser')
    return soup


# tbc with a, p, strong
def remove_tag(soup, tag_name):
    for tag in soup.findAll(tag_name):
        tag.replaceWithChildren()
    return soup


def list_to_string_helper(input_list):
    to_ret = ""

    for i in input_list:
        to_ret += (i + " ")

    return to_ret[:-1]


# returns the title, the relevant content
def get_content(soup):
    title = soup.select('h1.intro__degree-title')[0].text.strip()

    study_html = str(soup.find("div", {"id": "study"}))
    h2s = study_html.split("<h2")

    for h2 in h2s:
        if ' id="program-requirements">Program Requirements</h2>' in h2:
            content = h2[52:]
            return title, content


def create_jsons():
    degrees = get_degrees()
    years = [2013, 2014, 2015, 2016, 2017, 2018, 2019, 2020]

    for year in years:
        for degree in degrees:

            time.sleep(0.5)

            data = {}

            url = "https://programsandcourses.anu.edu.au/" + str(year) + "/program/" + str(degree) + "#study"

            try:
                soup = get_raw_html(url)
            except (ConnectionError, ConnectionRefusedError, ConnectionAbortedError, ConnectionResetError):
                continue

            soup = remove_tag(soup, 'a')
            soup = remove_tag(soup, 'p')
            soup = remove_tag(soup, 'strong')

            scraped_content = get_content(soup)
            if scraped_content is None:
                continue
            title, content = scraped_content

            if content is None:
                continue

            content = content.replace("<br>", "\n")
            content = content.replace("</br>", "\n")

            units = int(re.search(r'\d+', content).group())

            max_1000 = re.search("A maximum of \d+ units may come from completion of 1000-level courses", content)
            max_1000 = max_1000.group() if max_1000 is not None else None
            max_1000 = re.search("\d+", max_1000).group() if max_1000 is not None else None

            min_2000_3000 = re.search(
                "A minimum of \d+ units must come from completion of 2000- and 3000- level courses", content)
            min_2000_3000 = min_2000_3000.group() if min_2000_3000 is not None else None

            cbe_list_1 = re.search(
                "\d+ units from completion of courses (?:on|from) List 1 of the ANU College of Business and Economics",
                content)
            cbe_list_1 = cbe_list_1.group() if cbe_list_1 is not None else None
            cbe_list_1 = re.search("\d+", cbe_list_1).group() if cbe_list_1 is not None else None

            compulsory_courses = re.search("\d+ units from completion of the following compulsory courses", content)
            compulsory_courses = compulsory_courses.group() if compulsory_courses is not None else None

            compulsory_course_units = re.search("\d+",
                                                compulsory_courses).group() if compulsory_courses is not None else None

            # print("\n\nSummary of " + degree + "-" + str(year) + "\n")

            # print("Title: " + title)
            # print("Required Units for Degree: " + str(units))
            # print("Maximum units for 1000-level courses: " + str(max_1000))
            # print("Minimum units for 2000- and 3000-level courses: " + str(min_2000_3000))
            # print("Number of units from CBE List 1: " + str(cbe_list_1))
            # print("Units of compulsory courses: " + str(compulsory_course_units))

            data['name'] = title
            data['code'] = degree
            data['year'] = year
            data['units'] = int(units)

            required = {}
            x_from_here_list = []

            # add the restrictions on the number of courses per level to the json
            min_max_by_level = []
            if max_1000 is not None:
                min_max_1000 = {'type': 'maximum', 'level': '1000', 'units': int(max_1000)}
                min_max_by_level.append(min_max_1000)

            # if min_2000_3000 is not None:
            #     min_max_2000_3000 = {'type': 'minimum', 'level': '2000, 3000', 'units': int(min_2000_3000)}
            #     min_max_by_level.append(min_max_2000_3000)

            if min_max_by_level:
                required['max_by_level'] = min_max_by_level

            # add restrictions from CBE list 1
            if cbe_list_1 is not None:
                cbe = {'units': cbe_list_1, 'courses': "CBE List 1"}
                x_from_here_list.append(cbe)

            course_code_pattern = re.compile("^[A-Z]{4}\d{4}$")

            # parse the compulsory courses if known
            if compulsory_course_units is not None:
                num_courses = int(compulsory_course_units) / 6
                compulsory_course_list = []

                start_pos = content.find(compulsory_courses)

                course_count = 0

                for pos in range(start_pos + 45, min(start_pos + 1045, len(content) - 8)):
                    if course_count == num_courses:
                        break

                    if course_code_pattern.match(content[pos:pos + 8]):
                        compulsory_course_list.append(content[pos:pos + 8])
                        course_count += 1
                # print("Codes for compulsory courses: " + str(compulsory_course_list))

                required['compulsory_courses'] = compulsory_course_list

            # parse the one_of_x categories

            x_from_here = set()

            current_pos = 0
            while current_pos < len(content):
                temp = content[current_pos:]
                course_list = re.search(
                    "(?:6 units from completion of [a-zA-z\s]{0,50}course from the following list:|\d+ units from completion of [a-zA-z\s]{0,50}courses from the following list:)",
                    temp)
                if course_list is None:
                    break
                start, end = course_list.span()

                # check that there is no mention of the word compulsory. If there is, increment current_pos
                if 'compulsory' in course_list.group():
                    current_pos += (end - 1)
                    continue

                optional_course_num = int(re.search("\d+", course_list.group()).group()) / 6
                optional_course_list = []

                # find the next occurrence of the word "units"
                next_section = temp[end - 1:].find("units")

                if next_section == -1:
                    next_section = len(content) - 8

                for i in range(start, next_section + end - 1):
                    if course_code_pattern.match(temp[i:i + 8]):
                        optional_course_list.append(temp[i:i + 8])

                x_from_here.add("X_from_here: " + str(int(optional_course_num)) + " from " + list_to_string_helper(optional_course_list))

                current_pos += (end - 1)

            current_pos = 0
            while current_pos < len(content):
                temp = content[current_pos:]
                course_list = re.search(
                    "(?:A (minimum )?(maximum )?of 6 units from completion of (a )?(core )?course from the following list:|A (minimum )?(maximum )?of \d+ units from completion of (core )?courses from the following list:)",
                    temp)
                if course_list is None:
                    break
                start, end = course_list.span()
                min_max = course_list.group().split()[1]
                optional_course_num = int(re.search("\d+", course_list.group()).group()) / 6
                optional_course_list = []

                # find the next occurrence of the word "units"
                next_section = temp[end - 1:].find("units")

                if next_section == -1:
                    next_section = len(content) - 8

                for i in range(start, next_section + end - 1):
                    if course_code_pattern.match(temp[i:i + 8]):
                        optional_course_list.append(temp[i:i + 8])

                if "X_from_here: " + str(int(optional_course_num)) + " from " + list_to_string_helper(
                        optional_course_list) in x_from_here:
                    x_from_here.remove(
                        "X_from_here: " + str(int(optional_course_num)) + " from " + list_to_string_helper(optional_course_list))
                    x_from_here.add(
                        min_max + " X_from_here: " + str(int(optional_course_num)) + " from " + list_to_string_helper(optional_course_list))

                current_pos += (end - 1)

            # "stuff" would either look like
            #   Minimum X_from_here: 24 from [blah, blah]
            #   X_from_here: 24 from [blah, blah, blah]
            #   Maximum X_from_here: 24 from [blah, blah]
            for stuff in x_from_here:
                temp = {}
                if stuff[:3] == 'min':
                    temp['type'] = 'minimum'
                    temp['units'] = 6 * int(stuff.split()[2])
                    find_idx = stuff.find('from ')
                    temp['courses'] = (stuff[find_idx + 5:]).split()
                elif stuff[:3] == 'max':
                    temp['type'] = 'maximum'
                    temp['units'] = 6 * int(stuff.split()[2])
                    find_idx = stuff.find('from ')
                    temp['courses'] = (stuff[find_idx + 5:]).split()
                else:
                    temp['type'] = 'minimum'
                    temp['units'] = 6 * int(stuff.split()[1])
                    find_idx = stuff.find('from ')
                    temp['courses'] = (stuff[find_idx + 5:]).split()
                x_from_here_list.append(temp)

            if x_from_here_list:
                required['x_from_here'] = x_from_here_list
            data['required'] = required

            filename = "data/" + degree + "-" + str(year) + ".json"

            with open(filename, 'w') as outfile:
                json.dump(data, outfile, indent=2)


if __name__ == '__main__':
    create_jsons()
