from django.apps import AppConfig


class DegreeBuilderConfig(AppConfig):
    name = 'degree_builder'
