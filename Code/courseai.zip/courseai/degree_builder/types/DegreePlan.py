class DegreePlan:
    def __init__(self):
        print("stated")