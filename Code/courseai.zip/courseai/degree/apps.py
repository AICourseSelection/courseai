from django.apps import AppConfig


class DegreeConfig(AppConfig):
    name = 'degree'
